CREATE SEQUENCE seq_pessoa_pk;
 