-- insere institui��es
INSERT INTO t_instituicao (id,nome,deEnsino,numAlunos,numDocs) VALUES (1,'SAS-IPL','N',NULL,NULL);
INSERT INTO t_instituicao (id,nome,deEnsino,numAlunos,numDocs) VALUES (2,'ESTG','S',0,4);
INSERT INTO t_instituicao (id,nome,deEnsino,numAlunos,numDocs) VALUES (3,'ESEL','S',0,2);

COMMIT;