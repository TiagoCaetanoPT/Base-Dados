--EIBD1819_Ficha8.sql

@@ EIBD1819_Ficha8_eliminar
@@ EIBD1819_Ficha8_tabelas
@@ EIBD1819_Ficha8_dados
@@ EIBD1819_Ficha8_seqs
@@ EIBD1819_Ficha8_triggers
@@ EIBD1819_Ficha8_dados2
/
