DROP TABLE conta_cliente;
DROP TABLE conta;
DROP TABLE cliente;
DROP TABLE agencia;
DROP TABLE tipo_conta;
