-- op��es de ambiente do SQL*PLUS: n�o s�o comandos SQL
SET PAGESIZE 100;
SET LINESIZE 100;
SET SQLPROMPT FICHA1> ;

-- execu��o dos scripts da ficha 1
@@ ficha01_drops
@@ ficha01_tabelas
@@ ficha01_dados


