-- vers�o correcta 
DROP TABLE t_leitor;
DROP TABLE t_livro;

