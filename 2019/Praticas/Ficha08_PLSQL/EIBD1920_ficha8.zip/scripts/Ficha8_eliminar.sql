DROP TABLE telefone;
DROP TABLE docente;
DROP TABLE aluno;
DROP TABLE pessoa;
DROP TABLE instituicao_ensino;
DROP TABLE cantina;
DROP TABLE instituicao;
DROP TABLE docs_grau;



