-- Executar na conta das aulas:
--    conta "AULAS" na máquina Virutal 
--     OU 
--    conta "EInum_aluno" no servidor da escola

@@ ficha8_tabelas
@@ ficha8_subprogramas
@@ ficha8_dados
@@ ficha8_seqs
@@ ficha8_triggers
/
