﻿-- opções de ambiente do SQL*PLUS: não são comandos SQL
SET PAGESIZE 100;
SET LINESIZE 100;
SET SQLPROMPT FICHA2>;

-- execução dos scripts para criação do caso de estudo usado nas fichas 2,3,4,5 e SQL extra
@@ ficha2_drops
@@ ficha2_tabelas
@@ ficha2_dados
