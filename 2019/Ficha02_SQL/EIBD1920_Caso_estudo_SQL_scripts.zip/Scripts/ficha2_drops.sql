-- Eliminar todas as tabelas do caso de estudo
DROP TABLE historico_funcao;
DROP TABLE empregado;
DROP TABLE departamento;
DROP TABLE escala_salarial;
